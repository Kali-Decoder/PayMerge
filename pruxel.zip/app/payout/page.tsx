import PruxelPayout from "../../components/pruxel-payout"

export default function PayoutPage() {
  return <PruxelPayout />
}
