import PruxelLogin from "../../components/pruxel-login"

export default function LoginPage() {
  return <PruxelLogin />
}
