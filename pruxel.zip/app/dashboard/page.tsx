import PruxelDashboard from "../../components/pruxel-dashboard"

export default function DashboardPage() {
  return <PruxelDashboard />
}
