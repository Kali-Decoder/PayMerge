import PruxelLandingPremiumV3 from "../components/pruxel-landing"

export default function HomePage() {
  return <PruxelLandingPremiumV3 />
}
